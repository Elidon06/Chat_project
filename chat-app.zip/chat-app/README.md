# Node.js Real-Time Chat Application

## Description
A simple real-time chat application using Node.js, Express, and Socket.IO to demonstrate handling of multiple concurrent users.

## How to Run
1. Install dependencies: `npm install`
2. Run the server: `node server.js`
3. Open your browser and navigate to `http://localhost:3000`

## Features
- Real-time messaging
- Handles multiple users using WebSockets
